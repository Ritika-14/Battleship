package com.google.android.gms.location.project3_rraju;

public class Ship {
    public int number;
    public int size;
    public int direction;
    public int r;
    public int c;
    public int counter=0;

    public Ship(){

    }

    public Ship(int size, int direction, int number){
        this.number = number;
        this.size = size;
        this.direction=direction;
    }
    public void setRowCol(int r, int c){
        this.r = r;
        this.c = c;
    }


}
