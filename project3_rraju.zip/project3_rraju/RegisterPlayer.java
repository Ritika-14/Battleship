package com.google.android.gms.location.project3_rraju;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class RegisterPlayer extends AppCompatActivity {

    FirebaseDatabase database;
    DatabaseReference playerDbReference;
    String pName = "";
    Button login;
    EditText text;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_player);
        database = FirebaseDatabase.getInstance();
        login = findViewById(R.id.loginButton);
        text  = findViewById(R.id.name);
        SharedPreferences preferences = getSharedPreferences("PREFS", 0);
        pName = preferences.getString(pName, "");
        if(!pName.equals("")){
            playerDbReference = database.getReference("players/"+pName);
            addEventListener();
            playerDbReference.setValue("");
        }
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pName = text.getText().toString();
                text.setText("");
                if(!pName.equals("")){
                    login.setText("Logging in...");
                    login.setEnabled(false);
                    playerDbReference = database.getReference("players/"+pName);
                    addEventListener();
                    playerDbReference.setValue("");
                }
            }
        });
    }
    private void addEventListener(){
        playerDbReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Log.e("player red", String.valueOf(playerDbReference));
                if(!pName.equals("")){
                    SharedPreferences preferences = getSharedPreferences("PREFS", 0);
                    SharedPreferences.Editor editor = preferences.edit();
                    editor.putString("playerName", pName);
                    editor.apply();
                    startActivity(new Intent(getApplicationContext(), Room.class));
                    finish();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

                Toast.makeText(RegisterPlayer.this, "Error!", Toast.LENGTH_LONG).show();

            }
        });
    }
}