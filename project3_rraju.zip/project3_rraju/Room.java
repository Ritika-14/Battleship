package com.google.android.gms.location.project3_rraju;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class Room extends AppCompatActivity {

    ListView listview;
    Button button;
    List<String> roomsList;
    String playerName = "";
    String roomName = "";
    FirebaseDatabase database;
    DatabaseReference roomRef;
    DatabaseReference roomsRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_room);
        database = FirebaseDatabase.getInstance();
        SharedPreferences preferences = getSharedPreferences("PREFS", 0);
        playerName = preferences.getString("playerName", "");
        roomName = playerName;
        listview = findViewById(R.id.list);
        button = findViewById(R.id.createRoom);
        roomsList = new ArrayList();
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                button.setText("CREATING ROOM");
                button.setEnabled(false);
                roomName = playerName;
                roomRef = database.getReference("rooms/" + roomName);
                roomRef.child("shouldHostPlay").setValue("false");
                roomRef.child("players").child("player1").setValue(playerName).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        addRoomEventListener(task);
                    }
                });

            }
        });
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                roomName = roomsList.get(i);

                //check if only one player is present in the room/


                DatabaseReference players = database.getReference("rooms/"+roomName+"/players");

                players.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        int size = (int) dataSnapshot.getChildrenCount();

                        if(size == 1) {
                            roomRef = database.getReference("rooms/" + roomName);
                            if(!roomName.equals(playerName)) {
                                roomRef.child("players").child("player2").setValue(playerName).addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        addRoomEventListener(task);
                                    }
                                });
                            }
                            else{
                                Toast.makeText(Room.this, "Cannot join a room named after you!", Toast.LENGTH_LONG).show();

                            }
                        } else {
                            Toast.makeText(Room.this, "Error!", Toast.LENGTH_LONG).show();
                            Log.e("error", "Invalid room");
                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        Toast.makeText(Room.this, "Error!", Toast.LENGTH_LONG).show();
                        Log.e("error", "Invalid room");
                    }

                });
            }
        });


    }

    protected void onResume() {
        super.onResume();
        addRoomsEventListener();
//        DatabaseReference rooms = database.getReference("rooms");
//        Log.e("entering onresume", "entering onresume()");
//        rooms.addListenerForSingleValueEvent(new ValueEventListener() {
//            @Override
//            public void onDataChange(DataSnapshot dataSnapshot) {
//                roomsList.clear();
//                Iterable<DataSnapshot> rooms = dataSnapshot.getChildren();
//                for(DataSnapshot snap : rooms){
//                    roomsList.add(snap.getKey());
//                    Log.e("room key", snap.getKey());
//                    ArrayAdapter<String> adapter = new ArrayAdapter<>(Room.this, android.R.layout.simple_list_item_1, roomsList);
//                    listview.setAdapter(adapter);
//                }
//            }
//
//            @Override
//            public void onCancelled(DatabaseError databaseError) {
//                roomsList.clear();
//                ArrayAdapter<String> adapter = new ArrayAdapter<>(Room.this, android.R.layout.simple_list_item_1, roomsList);
//                Toast.makeText(Room.this, "Error!", Toast.LENGTH_LONG).show();
//            }
//
//        });
    }
    private void addRoomEventListener(Task<Void> task) {
        if (task.isSuccessful()) {
            button.setText("CREATE ROOM");
            button.setEnabled(true);
            Intent intent = new Intent(getApplicationContext(), MainActivity2.class);
            intent.putExtra("roomName", roomName);
            startActivity(intent);

        } else {
            button.setText("CREATE ROOM");
            button.setEnabled(true);
            Toast.makeText(Room.this, "Error!", Toast.LENGTH_LONG).show();
        }
    }

    private void addRoomsEventListener(){
        roomsList.clear();
        ArrayAdapter<String> adapter = new ArrayAdapter<>(Room.this, android.R.layout.simple_list_item_1, roomsList);
        listview.setAdapter(adapter);
        roomsRef = database.getReference("rooms");
        roomsRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                roomsList.clear();
                Log.e("reached here", "ok");
                Iterable<DataSnapshot> rooms = snapshot.getChildren();
                for(DataSnapshot snap : rooms){
                    roomsList.add(snap.getKey());

                }
                ArrayAdapter<String> adapter = new ArrayAdapter<>(Room.this, android.R.layout.simple_list_item_1, roomsList);
                listview.setAdapter(adapter);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}