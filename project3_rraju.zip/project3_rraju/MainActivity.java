package com.google.android.gms.location.project3_rraju;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class MainActivity extends AppCompatActivity  {
    public static int ROWS=8;
    public static int COLS=8;
    public static int HORIZONTAL= 0;
    public static int VERTICAL=1;
    public int boardComp[][] = new int[8][8];
    public int boardPlayer[][] = new int [8][8];
    ArrayList<Ship> ships1;
    ArrayList<Ship> ships2;
    public int buttonArray[][];
    public boolean isGameOver= false;
    ArrayList<int[]> index;

    public void fillArray(int board[][]){
        for(int i=0; i<8; i++)
        {
            for(int j=0;j<8;j++){
                board[i][j] = 0;
            }
        }
    }
    public boolean checkGameOver(ArrayList<Ship> ships){
        if(ships.size()==0) {
            isGameOver= true;
            return true;
        }
        else{
            return false;
        }
    }
    public void checkHitOrMiss(Button buttonB, boolean computer, int r, int c){
        int[][] board;
        ArrayList<Ship> ships;
        int colorOnHit = Color.RED;
        int colorOnMiss = Color.YELLOW;
        if(computer){
            board = boardComp;
            ships= ships2;
        }
        else{
            board = boardPlayer;
            ships= ships1;
        }

        if(board[r][c] > 0){
            buttonB.setBackgroundColor(colorOnHit);
            int shipNum = board[r][c];
            board[r][c]=0;
            for(int i=0;i<ships.size();i++){
                Ship identifiedShip = ships.get(i);
                if(identifiedShip.number == shipNum){
                    identifiedShip.counter++;
                    if(identifiedShip.counter == identifiedShip.size){
                        ships.remove(identifiedShip);
                    }
                    break;
                }
            }
            if(checkGameOver(ships)){
                Log.e("Game", "Game Over");
                TextView editText = (TextView) findViewById(R.id.textView4);
                Button goHome = findViewById(R.id.goHomeButton);
                goHome.setVisibility(View.VISIBLE);
                ConstraintLayout t= findViewById(R.id.consLayout);
                editText.setTextColor(Color.BLACK);
                if(computer){
                    editText.setText("Game Over. Computer Wins!", TextView.BufferType.EDITABLE);
                    editText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f);
                    editText.setBackgroundColor(Color.RED);
                    t.setBackgroundColor(Color.RED);
                }
                else{
                    editText.setText("Game Over. You Win!", TextView.BufferType.EDITABLE);
                    editText.setBackgroundColor(Color.GREEN);
                    t.setBackgroundColor(Color.GREEN);

                }
            }

        }
        else if(board[r][c]<=0) {
            buttonB.setBackgroundColor(colorOnMiss);

        }
//        else{
//            buttonB.setEnabled(false);
//        }

    }

    public void buttonOnClick(View v)
    {

        if(!isGameOver){
            Button myButton = (Button) findViewById(v.getId());
            Log.e("clicked", "duh");
            myButton.setEnabled(false);
            String s = myButton.getResources().getResourceEntryName(v.getId());
            int r = Integer.parseInt(String.valueOf(s.charAt(6)));
            int c = Integer.parseInt(String.valueOf(s.charAt(7)));
            Log.e("values", String.valueOf(boardPlayer[r][c]));
            checkHitOrMiss(myButton,false, r, c);
        }

        if(!isGameOver) {
            int val[] = index.remove(0);
            Random rand = new Random();
            int r1 = val[0];
            int c1 = val[1];
            Log.e("r1", String.valueOf(r1));
            Log.e("c1", String.valueOf(c1));
            Button toBeClicked = findViewById(buttonArray[r1][c1]);
            checkHitOrMiss(toBeClicked, true, r1, c1);
        }


    }
    public void goHomeClick(View view){
        finish();
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {



        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        fillArray(boardComp);
        fillArray(boardPlayer);

        buttonArray = new int [][]{{R.id.btn00, R.id.btn01, R.id.btn02, R.id.btn03, R.id.btn04, R.id.btn05, R.id.btn06, R.id.btn07},
                {R.id.btn10, R.id.btn11, R.id.btn12, R.id.btn13, R.id.btn14, R.id.btn15, R.id.btn16, R.id.btn17},
                {R.id.btn20, R.id.btn21, R.id.btn22, R.id.btn23, R.id.btn24, R.id.btn25, R.id.btn26, R.id.btn27},
                {R.id.btn30, R.id.btn31, R.id.btn32, R.id.btn33, R.id.btn34, R.id.btn35, R.id.btn36, R.id.btn37},
                {R.id.btn40, R.id.btn41, R.id.btn42, R.id.btn43, R.id.btn44, R.id.btn45, R.id.btn46, R.id.btn47},
                {R.id.btn50, R.id.btn51, R.id.btn52, R.id.btn53, R.id.btn54, R.id.btn55, R.id.btn56, R.id.btn57},
                {R.id.btn60, R.id.btn61, R.id.btn62, R.id.btn63, R.id.btn64, R.id.btn65, R.id.btn66, R.id.btn67},
                {R.id.btn70, R.id.btn71, R.id.btn72, R.id.btn73, R.id.btn74, R.id.btn75, R.id.btn76, R.id.btn77}};

        index = new ArrayList<>();
        for(int i=0;i <8;i++){
            for(int j=0;j<8;j++){
                int ar[] = new int[]{i,j};
                index.add(ar);
            }
        }
        Collections.shuffle(index);
        for(int i=0;i<64;i++){
            Log.e("array vals", String.valueOf(index.get(i)[0] + " "+ String.valueOf(index.get(i)[1])));
        }



        ships1 = new ArrayList<Ship>();
        ships2 = new ArrayList<Ship>();

        for(int i=0;i<4;i++) {
            createShip(boardPlayer, ships1, i + 1, false);
            createShip(boardComp, ships2, i + 1, true);
        }
        TableLayout tableLayout1 = (TableLayout) findViewById(R.id.tableLayout1);
        //Log.e("userClick called :",String.valueOf(R.id.button5));
        ConstraintLayout cons = (ConstraintLayout) findViewById(R.id.consLayout);
        cons.setBackgroundColor(Color.BLACK);
        TextView t = (TextView) findViewById(R.id.textView4);
        t.setTextColor(Color.WHITE);

    }
    protected void createShip(int board[][], ArrayList<Ship> ships, int i, boolean isComp) {
        Random rand = new Random();

        int size = 2+rand.nextInt(4);

        int number=i;
        int r = 0,c=0;
        int direction = rand.nextInt(2);
        Ship ship = new Ship(size, direction, number);
        Boolean placed = false;
        while (!placed) {
            if (direction == HORIZONTAL) {
                r = rand.nextInt(ROWS);
                c = rand.nextInt(COLS - size);
            }
            else {
                r = rand.nextInt(ROWS - size);
                c = rand.nextInt(COLS);
            }
            placed = true;

            if (direction == HORIZONTAL)
            {
                for (int j = 0; j < size; j++){
                    Log.e("r", String.valueOf(r));
                    Log.e("c", String.valueOf(c));
                    Log.e("j", String.valueOf(j));

                    if (board[r][c+j] != 0)
                        placed = false;
                }
            } else {
                for (int j = 0; j < size; j++)
                    if (board[r + j][c] != 0)
                        placed = false;
            }
            if (placed) {
                if (direction == HORIZONTAL) {
                    for (int j = 0; j < size; j++) {
                        board[r][c + j] = number;
                        if(isComp){
                            Button b = findViewById(buttonArray[r][c+j]);
                            b.setBackgroundColor(Color.GREEN);
                            b.setText(String.valueOf(number));
                        }
                    }
                }
                else {
                    for (int j = 0; j < size; j++) {
                        board[r + j][c] = number;
                        if(isComp){
                            Button b = findViewById(buttonArray[r+j][c]);
                            b.setBackgroundColor(Color.GREEN);
                            b.setText(String.valueOf(number));
                        }
                    }
                }
                ship.setRowCol(r, c);
            }
        }
//        Log.e("direction", String.valueOf(direction) );
//        Log.e("r,c", String.valueOf(r));
//        Log.e("r,c", (String.valueOf(c)));
//        Log.e("placed", String.valueOf(placed));
//        Log.e("size", String.valueOf(size));

        ships.add(ship);

    }

}