package com.google.android.gms.location.project3_rraju;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class MainActivity2 extends AppCompatActivity  {
    Button button;
    String playerName = "";
    String roomName = "";
    String role = "";
    String message = "";
    FirebaseDatabase database;
    DatabaseReference messageRef;
    public static int ROWS=8;
    public static int COLS=8;
    public static int HORIZONTAL= 0;
    public static int VERTICAL=1;
    public int boardComp[][] = new int[8][8];
    public int boardPlayer[][] = new int [8][8];
    ArrayList<Ship> ships1;
    ArrayList<Ship> ships2;
    public int buttonArray[][];
    public boolean isGameOver= false;
    ArrayList<int[]> index;
    public boolean shouldIPlay;
    DatabaseReference roomRef;
    Button b;
    boolean shouldShowInvalidRoom = false;


    public void fillArray(int board[][]){
        for(int i=0; i<8; i++)
        {
            for(int j=0;j<8;j++){
                board[i][j] = 0;
            }
        }
    }
    public boolean checkGameOver(ArrayList<Ship> ships){

        if(ships.size()==0) {
            isGameOver= true;
            return true;
        }
        else{
            return false;
        }
    }
    @Override
    protected void onStop() {
        super.onStop();  // Always call the superclass method first
        //Toast.makeText(getApplicationContext(), "onStop called", Toast.LENGTH_LONG).show();
        shouldShowInvalidRoom = true;
        DatabaseReference dRef = database.getReference().child("rooms/"+roomName);
        Log.e("dRef", String.valueOf(dRef));
        dRef.setValue(null);

    }
    public void checkHitOrMiss(Button buttonB, boolean isOpponent, int r, int c){
        int[][] board;
        ArrayList<Ship> ships;
        int colorOnHit = Color.RED;
        int colorOnMiss = Color.YELLOW;
        if(isOpponent){
            board = boardComp;
            ships= ships2;
        }
        else{
            board = boardPlayer;
            ships= ships1;
        }

        if(board[r][c] > 0){
            buttonB.setBackgroundColor(colorOnHit);
            int shipNum = board[r][c];
            board[r][c]=0;
            for(int i=0;i<ships.size();i++){
                Ship identifiedShip = ships.get(i);
                if(identifiedShip.number == shipNum){
                    identifiedShip.counter++;
                    if(identifiedShip.counter == identifiedShip.size){
                        ships.remove(identifiedShip);
                    }
                    break;
                }
            }
            if(checkGameOver(ships)){
                Log.e("Game", "Game Over");
                TextView editText = (TextView) findViewById(R.id.textView4);
                Button goHome = findViewById(R.id.goHomeButton);
                goHome.setVisibility(View.VISIBLE);
                ConstraintLayout t= findViewById(R.id.consLayout);
                editText.setTextColor(Color.BLACK);
                if(isOpponent){
                    editText.setText("Game Over. Opponent Wins!", TextView.BufferType.EDITABLE);
                    editText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f);
                    editText.setBackgroundColor(Color.RED);
                    t.setBackgroundColor(Color.RED);
                }
                else{
                    editText.setText("Game Over. You Win!", TextView.BufferType.EDITABLE);
                    editText.setBackgroundColor(Color.GREEN);
                    t.setBackgroundColor(Color.GREEN);

                }
            }

        }
        else if(board[r][c]<=0) {
            buttonB.setBackgroundColor(colorOnMiss);

        }
//        else{
//            buttonB.setEnabled(false);
//        }

    }

    public void buttonOnClick(View v)
    {

        if(!shouldIPlay){
            Toast.makeText(MainActivity2.this, "Waiting for other player to move!", Toast.LENGTH_LONG).show();
            return;
        }

        if(!isGameOver){
            Button myButton = (Button) findViewById(v.getId());
            Log.e("clicked", "duh");
            myButton.setEnabled(false);
            String s = myButton.getResources().getResourceEntryName(v.getId());
            int r = Integer.parseInt(String.valueOf(s.charAt(6)));
            int c = Integer.parseInt(String.valueOf(s.charAt(7)));
            //Log.e("values", String.valueOf(boardPlayer[r][c]));
            roomRef.child("rc").setValue(r+""+c);
            checkHitOrMiss(myButton,false, r, c);
            if(role.equals("host")){
                roomRef.child("shouldHostPlay").setValue("false");
            }
            else{
                roomRef.child("shouldHostPlay").setValue("true");
            }
        }



    }
    public void goHomeClick(View view){
        finish();
        DatabaseReference dRef = database.getReference().child("rooms/"+roomName);
        Log.e("dRef", String.valueOf(dRef));
        dRef.setValue(null);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        b = findViewById(R.id.goHomeButton);
        b.setText("Go to Room");
        SharedPreferences preferences = getSharedPreferences("PREFS", 0);
        playerName = preferences.getString("playerName", "");

        Bundle extras = getIntent().getExtras();
        if(extras != null){
            roomName = extras.getString("roomName");
            Log.e("room name", roomName + " " +playerName);
            Log.e("check name", String.valueOf(roomName.equals(playerName)));
            if (roomName.equals(playerName)){
                role = "host";
                shouldIPlay = false;
            }
            else{
                role = "guest";
                shouldIPlay = true;
            }
        }

        fillArray(boardComp);
        fillArray(boardPlayer);

        buttonArray = new int [][]{{R.id.btn00, R.id.btn01, R.id.btn02, R.id.btn03, R.id.btn04, R.id.btn05, R.id.btn06, R.id.btn07},
                {R.id.btn10, R.id.btn11, R.id.btn12, R.id.btn13, R.id.btn14, R.id.btn15, R.id.btn16, R.id.btn17},
                {R.id.btn20, R.id.btn21, R.id.btn22, R.id.btn23, R.id.btn24, R.id.btn25, R.id.btn26, R.id.btn27},
                {R.id.btn30, R.id.btn31, R.id.btn32, R.id.btn33, R.id.btn34, R.id.btn35, R.id.btn36, R.id.btn37},
                {R.id.btn40, R.id.btn41, R.id.btn42, R.id.btn43, R.id.btn44, R.id.btn45, R.id.btn46, R.id.btn47},
                {R.id.btn50, R.id.btn51, R.id.btn52, R.id.btn53, R.id.btn54, R.id.btn55, R.id.btn56, R.id.btn57},
                {R.id.btn60, R.id.btn61, R.id.btn62, R.id.btn63, R.id.btn64, R.id.btn65, R.id.btn66, R.id.btn67},
                {R.id.btn70, R.id.btn71, R.id.btn72, R.id.btn73, R.id.btn74, R.id.btn75, R.id.btn76, R.id.btn77}};

        index = new ArrayList<>();
        for(int i=0;i <8;i++){
            for(int j=0;j<8;j++){
                int ar[] = new int[]{i,j};
                index.add(ar);
            }
        }
        Collections.shuffle(index);
        for(int i=0;i<64;i++){
            Log.e("array vals", String.valueOf(index.get(i)[0] + " "+ String.valueOf(index.get(i)[1])));
        }



        ships1 = new ArrayList<Ship>();
        ships2 = new ArrayList<Ship>();

        database = FirebaseDatabase.getInstance();
        roomRef = database.getReference("rooms/" + roomName);
        roomRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if((snapshot.getValue())== null)
                        {
                            if(shouldShowInvalidRoom)
                                Toast.makeText(MainActivity2.this, "Invalid room. Opponent left.", Toast.LENGTH_LONG).show();
                            finish();
                        }

                }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        if(role.equals("host")) {
            for(int i=0;i<4;i++) {
                createShip(boardPlayer, ships1, i + 1, false);
                createShip(boardComp, ships2, i + 1, true);
            }
            roomRef.child("ships").child("host").setValue(ships1);
            roomRef.child("ships").child("guest").setValue(ships2);
        } else {
            DatabaseReference ships1Ref = roomRef.child("ships").child("guest");
            DatabaseReference ships2Ref = roomRef.child("ships").child("host");

            ships1Ref.addListenerForSingleValueEvent( new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        ships1.add(snapshot.getValue(Ship.class));

                    }
                    fillBoard(ships1, boardPlayer, false);
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {
                    // Getting Post failed, log a message
                    Log.w("error", "loadPost:onCancelled", databaseError.toException());
                }
            });

            ships2Ref.addListenerForSingleValueEvent( new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    // Get Post object and use the values to update the UI
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        ships2.add(snapshot.getValue(Ship.class));

                    }
                    fillBoard(ships2, boardComp, true);
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {
                    // Getting Post failed, log a message
                    Log.w("error", "loadPost:onCancelled", databaseError.toException());
                }
            });
        }
        DatabaseReference players = database.getReference("rooms/"+roomName+"/players");

        players.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                int size = (int) dataSnapshot.getChildrenCount();

                if(size == 2 && role.equals("host")) {
                    Toast.makeText(MainActivity2.this, "Guest joined. Waiting for guest to start!", Toast.LENGTH_LONG).show();
                }
                else if(size>2){
                    Toast.makeText(MainActivity2.this, "Invalid room", Toast.LENGTH_LONG).show();

                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(MainActivity2.this, "Error!", Toast.LENGTH_LONG).show();
                Log.e("error", "Invalid room");
            }

        });
        DatabaseReference rc = roomRef.child("rc");

        rc.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(MainActivity2.this, "Error!", Toast.LENGTH_LONG).show();
                Log.e("error", "Invalid room");
            }

        });


        DatabaseReference shouldHostPlay = roomRef.child("shouldHostPlay");
        shouldHostPlay.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String shouldHostPlay  = (String) dataSnapshot.getValue();
                //Log.e("shouldHostPlay", shouldHostPlay);
                if(shouldHostPlay == null)
                    return;

                if(role.equals("host") && shouldHostPlay.equals("false")){
                    shouldIPlay = false;
                }
                else if (role.equals("guest") && shouldHostPlay.equals("false")){
                    shouldIPlay= true;
                }
                else if(role.equals("host") && shouldHostPlay.equals("true")){
                    shouldIPlay = true;

                }
                else if (role.equals("guest") && shouldHostPlay.equals("true")){
                 shouldIPlay = false;
                }
                rc.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if(shouldIPlay){
                            String rowCol = (String) snapshot.getValue();
                            //rc was updated by other player

                            if(!isGameOver && rowCol != null && rowCol.length()==2) {

                                int r1 = Integer.parseInt(String.valueOf((rowCol.charAt(0))));
                                int c1 = Integer.parseInt(String.valueOf((rowCol.charAt(1))));
                                Log.e("r1", String.valueOf(r1));
                                Log.e("c1", String.valueOf(c1));
                                Button toBeClicked = findViewById(buttonArray[r1][c1]);
                                checkHitOrMiss(toBeClicked, true, r1, c1);
                            }

                        }
                        else{
                            //rc was updated by me
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(MainActivity2.this, "Error!", Toast.LENGTH_LONG).show();
                Log.e("error", "Invalid room");
            }

        });

        TableLayout tableLayout1 = (TableLayout) findViewById(R.id.tableLayout1);
        //Log.e("userClick called :",String.valueOf(R.id.button5));
        ConstraintLayout cons = (ConstraintLayout) findViewById(R.id.consLayout);
        cons.setBackgroundColor(Color.BLACK);
        TextView t = (TextView) findViewById(R.id.textView4);
        t.setTextColor(Color.WHITE);

    }

   public void fillBoard(ArrayList<Ship> ships, int board[][], boolean isHostBoard){
        for(int i=0;i<ships.size();i++){
            Ship s = ships.get(i);
            int r= s.r;
            int c = s.c;
            int size = s.size;
            int direction = s.direction;
            int number = s.number;
            if (direction == HORIZONTAL) {
                for (int j = 0; j < size; j++) {
                    board[r][c + j] = number;
                    if(isHostBoard){
                        Button b = findViewById(buttonArray[r][c+j]);
                        b.setBackgroundColor(Color.GREEN);
                        b.setText(String.valueOf(number));
                    }
                }
            }
            else {
                for (int j = 0; j < size; j++) {
                    board[r + j][c] = number;
                    if(isHostBoard){
                        Button b = findViewById(buttonArray[r+j][c]);
                        b.setBackgroundColor(Color.GREEN);
                        b.setText(String.valueOf(number));
                    }
                }
            }


        }

   }
    protected void createShip(int board[][], ArrayList<Ship> ships, int i, boolean isComp) {
        Random rand = new Random();

        int size = 2+rand.nextInt(4);

        int number=i;
        int r = 0,c=0;
        int direction = rand.nextInt(2);
        Ship ship = new Ship(size, direction, number);
        Boolean placed = false;
        while (!placed) {
            if (direction == HORIZONTAL) {
                r = rand.nextInt(ROWS);
                c = rand.nextInt(COLS - size);
            }
            else {
                r = rand.nextInt(ROWS - size);
                c = rand.nextInt(COLS);
            }
            placed = true;

            if (direction == HORIZONTAL)
            {
                for (int j = 0; j < size; j++){

                    if (board[r][c+j] != 0)
                        placed = false;
                }
            } else {
                for (int j = 0; j < size; j++)
                    if (board[r + j][c] != 0)
                        placed = false;
            }
            if (placed) {
                if (direction == HORIZONTAL) {
                    for (int j = 0; j < size; j++) {
                        board[r][c + j] = number;
                        if(isComp){
                            Button b = findViewById(buttonArray[r][c+j]);
                            b.setBackgroundColor(Color.GREEN);
                            b.setText(String.valueOf(number));
                        }
                    }
                }
                else {
                    for (int j = 0; j < size; j++) {
                        board[r + j][c] = number;
                        if(isComp){
                            Button b = findViewById(buttonArray[r+j][c]);
                            b.setBackgroundColor(Color.GREEN);
                            b.setText(String.valueOf(number));
                        }
                    }
                }
                ship.setRowCol(r, c);
            }
        }

        ships.add(ship);

    }

}





