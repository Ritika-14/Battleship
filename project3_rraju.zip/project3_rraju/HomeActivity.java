package com.google.android.gms.location.project3_rraju;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class HomeActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ConstraintLayout cons = (ConstraintLayout) findViewById(R.id.consLayout);
        cons.setBackgroundColor(Color.BLACK);
        TextView t = (TextView) findViewById(R.id.textView);
        t.setTextColor(Color.WHITE);

    }
    public void playAgainstComputer(android.view.View view){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);

    }

    public void playWithFriend(View view) {
        Intent intent = new Intent(this, RegisterPlayer.class);
        startActivity(intent);

    }
}